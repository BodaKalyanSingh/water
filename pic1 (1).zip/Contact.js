import React, { useState } from 'react';
import './Contact.css';

const initForm = {
  name: '', email: '', phone: '', service: '', message: '',
};

const services = [
  'New Purifier Purchase',
  'AMC (Annual Maintenance)',
  'Repair / Service',
  'Filter Replacement',
  'Product Enquiry',
  'Other',
];

export default function Contact() {
  const [form, setForm] = useState(initForm);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim())    e.name    = 'Name is required';
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email))
                              e.email   = 'Valid email is required';
    if (!form.phone.trim() || form.phone.length < 10)
                              e.phone   = 'Valid phone number required';
    if (!form.service)        e.service = 'Please select a service';
    if (!form.message.trim()) e.message = 'Message is required';
    return e;
  };

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(p => ({ ...p, [name]: value }));
    if (errors[name]) setErrors(p => ({ ...p, [name]: '' }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    const v = validate();
    if (Object.keys(v).length) { setErrors(v); return; }
    setSubmitted(true);
  };

  const contactInfo = [
    { icon: '📞', label: 'Phone', values: ['+91 98765 43210', '+91 98765 43211'] },
    { icon: '📧', label: 'Email', values: ['info@ashwiniwater.in', 'support@ashwiniwater.in'] },
    { icon: '📍', label: 'Address', values: ['123, Water Works Road', 'Hyderabad, Telangana – 500001'] },
    { icon: '🕐', label: 'Working Hours', values: ['Mon – Sat: 9 AM – 7 PM', 'Sunday: 10 AM – 4 PM'] },
  ];

  return (
    <>
      <section className="page-hero">
        <div className="page-hero__bg" />
        <div className="container page-hero__inner">
          <p className="tag anim-fadeup">Reach Us</p>
          <h1 className="page-hero__title anim-fadeup anim-delay-1">
            Get In <span>Touch</span>
          </h1>
          <p className="page-hero__sub anim-fadeup anim-delay-2">
            Have questions? Need a quote? Our team is ready to help you find the right solution.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container contact-layout">

          {/* Contact Info */}
          <div className="contact-info">
            <p className="tag">Contact Details</p>
            <h2 className="section-title">Let's Talk</h2>
            <div className="divider" />
            <p className="section-sub">Reach out via phone, email, or walk into our showroom. We're here to help.</p>

            <div className="info-cards">
              {contactInfo.map((item, i) => (
                <div className="info-card" key={i}>
                  <span className="info-icon">{item.icon}</span>
                  <div>
                    <strong>{item.label}</strong>
                    {item.values.map((v, j) => <span key={j}>{v}</span>)}
                  </div>
                </div>
              ))}
            </div>

            <div className="contact-social">
              <span>Follow Us:</span>
              <a href="#" aria-label="Facebook" className="social-btn">📘</a>
              <a href="#" aria-label="Instagram" className="social-btn">📸</a>
              <a href="#" aria-label="WhatsApp" className="social-btn">💬</a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="contact-form-wrap">
            {submitted ? (
              <div className="success-message">
                <div className="success-icon">✅</div>
                <h3>Thank You!</h3>
                <p>Your enquiry has been submitted. Our team will contact you within 24 hours.</p>
                <button className="btn btn-primary" onClick={() => { setSubmitted(false); setForm(initForm); }}>
                  Submit Another
                </button>
              </div>
            ) : (
              <form className="contact-form" onSubmit={handleSubmit} noValidate>
                <h3>Send an Enquiry</h3>
                <p>Fill in the details below and we'll get back to you promptly.</p>

                <div className="form-row">
                  <div className={`form-group ${errors.name ? 'has-error' : ''}`}>
                    <label>Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                    />
                    {errors.name && <span className="error-msg">{errors.name}</span>}
                  </div>

                  <div className={`form-group ${errors.phone ? 'has-error' : ''}`}>
                    <label>Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="+91 XXXXX XXXXX"
                    />
                    {errors.phone && <span className="error-msg">{errors.phone}</span>}
                  </div>
                </div>

                <div className={`form-group ${errors.email ? 'has-error' : ''}`}>
                  <label>Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="you@example.com"
                  />
                  {errors.email && <span className="error-msg">{errors.email}</span>}
                </div>

                <div className={`form-group ${errors.service ? 'has-error' : ''}`}>
                  <label>Service Required *</label>
                  <select name="service" value={form.service} onChange={handleChange}>
                    <option value="">-- Select a service --</option>
                    {services.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  {errors.service && <span className="error-msg">{errors.service}</span>}
                </div>

                <div className={`form-group ${errors.message ? 'has-error' : ''}`}>
                  <label>Your Message *</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Tell us more about your requirement..."
                    rows={5}
                  />
                  {errors.message && <span className="error-msg">{errors.message}</span>}
                </div>

                <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                  Submit Enquiry →
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <div className="map-placeholder">
        <div className="map-overlay">
          <span>📍 Ashwini Water Solutions, Hyderabad</span>
          <a
            href="https://maps.google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-white"
          >
            Open in Maps
          </a>
        </div>
      </div>
    </>
  );
}
